from setuptools import setup

setup(name='dsyl',
      version='0.5',
      description='Common Functions',
      packages=['dsyl'],
      author = 'Yang Lyu',
      author_email = 'smart.lvyang@gmail.com',
      zip_safe=False)
