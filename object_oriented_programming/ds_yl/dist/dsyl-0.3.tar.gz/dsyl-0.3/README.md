
# Udacity Data Scientist Nanodegree Project

This package contains Binomial and Gaussian classes
This project is uploaded to PyPi and is subject to further development
