from setuptools import setup

setup(name='ds_yl',
      version='0.1',
      description='Common Functions',
      packages=['ds_yl'],
      author = 'Yang Lyu',
      author_email = 'smart.lvyang@gmail.com',
      zip_safe=False)
