from setuptools import setup

setup(name='dist_package_yl',
      version='0.1',
      description='Gaussian distributions',
      packages=['dist_package_yl'],
      author = 'Yang Lyu',
      author_email = 'smart.lvyang@gmail.com',
      zip_safe=False)
